# QuizMaster Pro

A responsive API-powered quiz application for mobile, tablet and desktop.

## Run
Open `index.html` in a browser. No traditional backend is required.

## API
Uses Open Trivia DB:
https://opentdb.com/api.php

The app uses a session token when available and shuffles returned questions/options. Open Trivia DB documents a maximum of 50 questions per call and token support for avoiding repeats. API availability/rate limits can vary.

## Included
- Student name
- Subject and difficulty selection
- 10/20/35/50 questions
- Per-question countdown
- Randomized answer options
- API questions
- Fallback questions if the API is unavailable/limited
- Auto scoring
- Percentage and grade
- Performance remark
- Attempt history in LocalStorage
- Dark/light mode
- Responsive mobile/PC UI
