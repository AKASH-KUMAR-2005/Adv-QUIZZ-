const $=s=>document.querySelector(s);
const state={questions:[],answers:{},current:0,timer:null,timeLeft:0,settings:{},sessionToken:null};
const fallback=[
["What does CPU stand for?","Central Processing Unit",["Central Processing Unit","Computer Personal Unit","Central Program Utility","Control Processing User"]],
["Which data structure follows FIFO order?","Queue",["Stack","Queue","Tree","Graph"]],
["Which protocol is used to securely transfer web pages?","HTTPS",["FTP","HTTP","HTTPS","SMTP"]],
["Which language is primarily used to style web pages?","CSS",["HTML","CSS","SQL","JSON"]],
["What is the binary representation of decimal 10?","1010",["1001","1010","1100","1110"]],
["Which memory is volatile?","RAM",["ROM","SSD","RAM","HDD"]],
["Which SQL command retrieves data?","SELECT",["INSERT","UPDATE","SELECT","DELETE"]],
["Which device connects different networks?","Router",["Switch","Router","Repeater","Hub"]],
["What does OOP stand for?","Object-Oriented Programming",["Object-Oriented Programming","Open Online Protocol","Ordered Object Process","Operating Output Program"]],
["Which HTTP status code means Not Found?","404",["200","301","404","500"]]
];
const subjectMap={computer:18,general:9,science:17,history:23,geography:22,animals:27};
const esc=s=>{const d=document.createElement("div");d.textContent=s;return d.innerHTML};
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$("#"+id).classList.add("active");scrollTo(0,0)}
function toast(m){const t=$("#toast");t.textContent=m;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function decode(s){const t=document.createElement("textarea");t.innerHTML=s;return t.value}
function saveHistory(){
 const h=JSON.parse(localStorage.getItem("quizHistory")||"[]");
 h.unshift({name:state.settings.name,subject:state.settings.subject,difficulty:state.settings.difficulty,score:score(),total:state.questions.length,pct:Math.round(score()/state.questions.length*100),date:new Date().toLocaleString()});
 localStorage.setItem("quizHistory",JSON.stringify(h.slice(0,15)));renderHistory();
}
function renderHistory(){
 const h=JSON.parse(localStorage.getItem("quizHistory")||"[]"),box=$("#history");
 if(!h.length){box.innerHTML='<div class="empty">No attempts yet.</div>';return}
 box.innerHTML=h.map(x=>`<div class="history-item"><div><b>${esc(x.name||"Student")}</b><small>${esc(x.subject)} • ${esc(x.difficulty)} • ${esc(x.date)}</small></div><div class="history-score">${x.score}/${x.total}<small>${x.pct}%</small></div></div>`).join("");
}
async function getToken(){
 try{const r=await fetch("https://opentdb.com/api_token.php?command=request");const d=await r.json();return d.response_code===0?d.token:null}catch(e){return null}
}
async function fetchQuestions(amount,diff,subject){
 const params=new URLSearchParams({amount:String(Math.min(amount,50)),difficulty:diff,type:"multiple",encode:"url3986"});
 if(subjectMap[subject])params.set("category",subjectMap[subject]);
 if(!state.sessionToken)state.sessionToken=await getToken();
 if(state.sessionToken)params.set("token",state.sessionToken);
 let url="https://opentdb.com/api.php?"+params;
 try{
   let r=await fetch(url); let d=await r.json();
   if(d.response_code===4){state.sessionToken=await getToken(); if(state.sessionToken){params.set("token",state.sessionToken);r=await fetch("https://opentdb.com/api.php?"+params);d=await r.json()}}
   if(d.response_code===0 && d.results?.length)return d.results.map(q=>({question:decodeURIComponent(q.question),correct:decodeURIComponent(q.correct_answer),options:[decodeURIComponent(q.correct_answer),...q.incorrect_answers.map(decodeURIComponent)].sort(()=>Math.random()-.5)}));
 }catch(e){}
 return null;
}
function makeFallback(n){return Array.from({length:n},(_,i)=>{const q=fallback[i%fallback.length];return {question:q[0],correct:q[1],options:[...q[3]].sort(()=>Math.random()-.5)}})}
async function start(){
 const name=$("#studentName").value.trim()||"Student",amount=+$("#amount").value,diff=$("#difficulty").value,subject=$("#subject").value,time=+$("#timePerQuestion").value;
 $("#homeError").classList.add("hidden");$("#startBtn").disabled=true;$("#startBtn").textContent="Loading questions…";
 state.settings={name,amount,diff,subject,time};
 let qs=await fetchQuestions(amount,diff,subject);
 if(!qs || qs.length<amount){const extra=makeFallback(amount-(qs?.length||0));qs=[...(qs||[]),...extra];toast("API returned limited questions; fallback questions added.");}
 state.questions=qs.slice(0,amount);state.answers={};state.current=0;$("#quizSubject").textContent=subject.toUpperCase();$("#quizTitle").textContent=`${diff[0].toUpperCase()+diff.slice(1)} Quiz`;
 $("#startBtn").disabled=false;$("#startBtn").innerHTML="Start Quiz <span>→</span>";show("quiz");renderQuestion();
}
function score(){return state.questions.reduce((n,q,i)=>n+(state.answers[i]===q.correct?1:0),0)}
function renderQuestion(){
 const q=state.questions[state.current],total=state.questions.length;
 $("#qNumber").textContent=String(state.current+1).padStart(2,"0");$("#questionText").textContent=q.question;
 $("#progressText").textContent=`Question ${state.current+1} of ${total}`;$("#scoreLive").textContent=`${score()} correct`;
 $("#progressBar").style.width=((state.current+1)/total*100)+"%";
 $("#options").innerHTML=q.options.map((o,i)=>`<button class="option ${state.answers[state.current]===o?"selected":""}" data-value="${encodeURIComponent(o)}"><span class="letter">${String.fromCharCode(65+i)}</span><span>${esc(o)}</span></button>`).join("");
 document.querySelectorAll(".option").forEach(b=>b.onclick=()=>{state.answers[state.current]=decodeURIComponent(b.dataset.value);renderQuestion();});
 $("#prevBtn").disabled=state.current===0;$("#nextBtn").textContent=state.current===total-1?"Finish →":"Next →";
 renderNav();startTimer();
}
function renderNav(){
 $("#navGrid").innerHTML=state.questions.map((_,i)=>`<button class="nav-dot ${i===state.current?"current":""} ${state.answers[i]?"done":""}" data-i="${i}">${i+1}</button>`).join("");
 document.querySelectorAll(".nav-dot").forEach(b=>b.onclick=()=>{state.current=+b.dataset.i;renderQuestion()});
}
function startTimer(){
 clearInterval(state.timer);state.timeLeft=state.settings.time;
 updateTimer();state.timer=setInterval(()=>{state.timeLeft--;updateTimer();if(state.timeLeft<=0){clearInterval(state.timer);toast("Time is up — moving to the next question.");next()}},1000)
}
function updateTimer(){$("#timer").textContent=`00:${String(state.timeLeft).padStart(2,"0")}`;$("#timer").classList.toggle("danger",state.timeLeft<=10)}
function next(){if(state.current===state.questions.length-1){finish()}else{state.current++;renderQuestion()}}
function finish(){
 clearInterval(state.timer);saveHistory();
 const s=score(),t=state.questions.length,p=Math.round(s/t*100),wrong=Object.keys(state.answers).length-s,skip=t-Object.keys(state.answers).length;
 let grade=p>=90?"A+":p>=80?"A":p>=70?"B":p>=60?"C":p>=50?"D":"F";
 let remark=p>=90?"Outstanding performance!":p>=80?"Excellent work!":p>=70?"Good job — keep improving.":p>=60?"Nice effort — practice more.":"Keep practicing and try again.";
 $("#resultTitle").textContent=`Well done, ${state.settings.name}!`;$("#finalPercent").textContent=p+"%";$("#finalGrade").textContent="Grade "+grade;$("#remark").textContent=remark;
 $("#correctCount").textContent=s;$("#wrongCount").textContent=wrong;$("#unansweredCount").textContent=skip;$("#finalScore").textContent=`${s}/${t}`;renderHistory();show("result");
}
$("#startBtn").onclick=start;$("#nextBtn").onclick=next;$("#prevBtn").onclick=()=>{if(state.current>0){state.current--;renderQuestion()}};$("#finishBtn").onclick=()=>{if(confirm("Submit the quiz now?"))finish()};$("#retryBtn").onclick=start;$("#homeBtn").onclick=()=>show("home");$("#clearHistory").onclick=()=>{localStorage.removeItem("quizHistory");renderHistory()};$("#themeBtn").onclick=()=>{document.body.classList.toggle("light");localStorage.setItem("theme",document.body.classList.contains("light")?"light":"dark")};
if(localStorage.getItem("theme")==="light")document.body.classList.add("light");renderHistory();
window.addEventListener("beforeunload",e=>{if($("#quiz").classList.contains("active")){e.preventDefault();e.returnValue=""}});
